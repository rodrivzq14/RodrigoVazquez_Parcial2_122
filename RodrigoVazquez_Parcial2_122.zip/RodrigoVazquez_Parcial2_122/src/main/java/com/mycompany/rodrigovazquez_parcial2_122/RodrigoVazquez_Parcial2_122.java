package com.mycompany.rodrigovazquez_parcial2_122;

import model.Cancion;
import model.GeneroMusical;
import static config.RutasArchivo.getRutaBinarioString;
import static config.RutasArchivo.getRutaCSVString;
import java.io.IOException;
import service.CatalogoMusical;

public class RodrigoVazquez_Parcial2_122 {

    public static void main(String[] args) {
        try {
            CatalogoMusical<Cancion> catalogo = new CatalogoMusical<>();
            catalogo.agregar(new Cancion(1, "Bohemian Rhapsody", "Queen", GeneroMusical.ROCK));
            catalogo.agregar(new Cancion(2, "Billie Jean", "Michael Jackson", GeneroMusical.POP));
            catalogo.agregar(new Cancion(3, "Shape of You", "Ed Sheeran", GeneroMusical.POP));
            catalogo.agregar(new Cancion(4, "Take Five", "Dave Brubeck", GeneroMusical.JAZZ));
            catalogo.agregar(new Cancion(5, "Canon in D", "Pachelbel", GeneroMusical.CLASICA));

            System.out.println("Catálogo de canciones:");
            catalogo.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCanciones de género POP:");
            catalogo.filtrar(c -> c.getGenero() == GeneroMusical.POP)
                   .forEach(c -> System.out.println(c));

            System.out.println("\nCanciones cuyo título contiene 'shape':");
            catalogo.filtrar(c -> c.getTitulo().toLowerCase().contains("shape"))
                   .forEach(c -> System.out.println(c));

            System.out.println("\nCanciones ordenadas por ID:");
            catalogo.ordenar();
            catalogo.paraCadaElemento(c -> System.out.println(c));

            System.out.println("\nCanciones ordenadas por artista:");
            catalogo.ordenar((c1, c2) -> c1.getArtista().compareToIgnoreCase(c2.getArtista()));
            catalogo.paraCadaElemento(c -> System.out.println(c));

            catalogo.guardarEnArchivo(getRutaBinarioString());

            CatalogoMusical<Cancion> cargado = new CatalogoMusical<>();
            cargado.cargarDesdeArchivo(getRutaBinarioString());

            System.out.println("\nCanciones cargadas desde binario:");
            cargado.paraCadaElemento(c -> System.out.println(c));

            catalogo.guardarEnCSV(getRutaCSVString());

            cargado.cargarDesdeCSV(getRutaCSVString(), linea -> Cancion.fromCSV(linea));

            System.out.println("\nCanciones cargadas desde CSV:");
            cargado.paraCadaElemento(c -> System.out.println(c));

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }
}
