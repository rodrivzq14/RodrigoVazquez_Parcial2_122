package service;

import model.CSVSerializable;
import model.Cancion;
import static model.Cancion.fromCSV;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;

public class CatalogoMusical<T extends CSVSerializable & Serializable &Comparable<T>> implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private List<T> canciones;

    public CatalogoMusical() {
        canciones = new ArrayList<>();
    }
    
    public void agregar(T elem){
        validarCancion(elem);
        canciones.add(elem);
    }
    
    public void validarCancion(T elem){
        if (canciones.contains(elem)){
            throw new IllegalArgumentException("La cancion ya se encuentra en el catalogo");
        }
    }
    
    public T obtener(int indice) {
        validarIndice(indice);
        return canciones.get(indice);
    }

    public void eliminar(int indice) {
        validarIndice(indice);
        canciones.remove(indice);
    }
    
    public void validarIndice(int indice){
        if (indice < 0 || indice > canciones.size()){
            throw new IndexOutOfBoundsException("Indice invalido");
        }
    }
    
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> filtrado = new ArrayList<>();
        for (T elem : canciones) {
            if (criterio.test(elem)) {
                filtrado.add(elem);
            }
        }
        return filtrado;
    }
 
    public void ordenar(){
        Collections.sort(canciones);
    }
    
    public void ordenar(Comparator<? super T> comparador){
            canciones.sort(comparador);
    }
    
    public void paraCadaElemento(Consumer<? super T> accion) {
        for (T elem : canciones) {
            accion.accept(elem);
        }
    }
    
    public void guardarEnArchivo(String ruta) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ruta))) {
            salida.writeObject(canciones);
        }
    }

    public void cargarDesdeArchivo(String ruta) throws IOException, ClassNotFoundException{
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(ruta))){
            canciones = (List<T>) entrada.readObject();
        }
    }
    
    public void guardarEnCSV(String ruta) throws IOException{
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))){
            for(T elem : canciones){
                bw.write(elem.toCSV() + "\n");
            }
        }
    }
    
    public void cargarDesdeCSV(String ruta, Function<String, T> fromCSV) throws IOException {
        List<T> lista = null;
        try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
            lista = new ArrayList<>();
            String linea;
            while ((linea = br.readLine()) != null) {
               lista.add(fromCSV.apply(linea));
            }
        }
        this.canciones = lista;
    }
    
}
