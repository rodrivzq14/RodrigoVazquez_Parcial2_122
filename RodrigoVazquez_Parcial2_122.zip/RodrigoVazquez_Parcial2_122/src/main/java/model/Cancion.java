package model;

import java.io.Serializable;
import java.util.Objects;

public class Cancion implements Comparable<Cancion>, CSVSerializable, Serializable {
    
    private static final long serialVersionUID = 1L;
    private int id;
    private String titulo;
    private String artista;
    private GeneroMusical genero;

    public Cancion(int id, String titulo, String artista, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public void setGenero(GeneroMusical genero) {
        this.genero = genero;
    }
    
    public static Cancion fromCSV(String csvLine) {
        String[] campos = csvLine.split(",", 4);
        if (campos.length < 4) {
            throw new IllegalArgumentException("CSV inválido para Cancion");
        }
        int id = Integer.parseInt(campos[0]);
        String titulo = campos[1];
        String artista = campos[2];
        GeneroMusical genero = GeneroMusical.valueOf(campos[3]);
        return new Cancion(id, titulo, artista, genero);
    }

    @Override
    public String toString() {
        return "Cancion{" + "id=" + id + ", titulo=" + titulo + ", artista=" + artista + ", genero=" + genero + '}';
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(id, titulo, artista, genero);
    }
    
    @Override
    public boolean equals(Object o){
        if (o == null || !(o instanceof Cancion c)){
            return false;
        }
        return id == c.id && titulo.equals(c.titulo) && artista.equals(c.artista) && genero == c.genero;
    }

    @Override
    public int compareTo(Cancion c) {
        return Integer.compare(c.id, id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + artista + "," + genero.name();
    }
    
}
